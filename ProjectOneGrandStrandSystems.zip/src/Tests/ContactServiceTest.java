package Tests;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import Services.ContactService;

class ContactServiceTest {
	
	// To test adding new contacts and throwing errors when duplicate ID is referenced
	@Test
	void testContactServiceAddClass() {
		ContactService temporary = new ContactService();
		temporary.addContact("111", "spongebob", "squarepant", "5551234567", "124 Conch Street");
		temporary.addContact("222", "squidward", "tentacles", "5557654321", "126 Conch Street");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			temporary.addContact("111", "patrick", "star", "5559874321", "128 Conch Street");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			temporary.addContact(null, "patrick", "star", "5559874321", "128 Conch Street");
		});
	}
	
	// To test deleting a contact and throws error when trying to delete a contact that isn't there
	@Test
	void testContactServiceDeleteContact() {
		ContactService temporary = new ContactService();
		temporary.addContact("111", "spongebob", "squarepant", "5551234567", "124 Conch Street");
		temporary.deleteContact("111");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			temporary.deleteContact("111");
		});
	}
	
	// To test updating a contact after it has been created
	@Test
	void testContactServiceUpdateContact() {
		ContactService temporary = new ContactService();
		temporary.addContact("25", "Barry", "Bonds", "4159722000", "24 Willie Mays Plaza");
		temporary.updateContact("25", "FirstName", "Mark");
		temporary.updateContact("25", "LastName", "McGwire");
		temporary.updateContact("25", "PhoneNumber", "3143459600");
		temporary.updateContact("25", "Address", "700 Clark Avenue");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			temporary.updateContact("2", "temp", "temp");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			temporary.updateContact(null, "temp", "temp");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			temporary.updateContact("25", "temp", "temp");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			temporary.updateContact("25", "FirstName", null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			temporary.updateContact("25", null, "temp");
		});
	}
}
