package Tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import Services.Contact;

class ContactTest {
	
	// To test the constructor of contact class
	@Test
	void testContactClass() {
		Contact contact = new Contact("111", "spongebob", "squarepant", "5551234567", "124 Conch Street" );
		assertTrue(contact.getid().equals("111"));
		assertTrue(contact.getFirstName().equals("spongebob"));
		assertTrue(contact.getLastName().equals("squarepant"));
		assertTrue(contact.getNumber().equals("5551234567"));
		assertTrue(contact.getAddress().equals("124 Conch Street"));
	}
	
	// To test that incorrect values throw the appropriate errors
	@Test
	void testContactClassArgs() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "spongebob", "squarepant", "5551234567", "124 Conch Street" );
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("", "spongebob", "squarepant", "5551234567", "124 Conch Street" );
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "spongebob", "squarepant", "5551234567", "124 Conch Street" );
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("111", null, "squarepant", "5551234567", "124 Conch Street" );
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("111", "", "squarepant", "5551234567", "124 Conch Street" );
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("111", "spoongeboob", "squarepant", "5551234567", "124 Conch Street" );
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("111", "spongebob", null, "5551234567", "124 Conch Street" );
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("111", "spongebob", "", "5551234567", "124 Conch Street" );
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("111", "spongebob", "squarepants", "5551234567", "124 Conch Street" );
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("111", "spongebob", "squarepant", "555123456", "124 Conch Street" );
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("111", "spongebob", "squarepant", "55551234567", "124 Conch Street" );
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("111", "spongebob", "squarepant", null, "124 Conch Street" );
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("111", "spongebob", "squarepant", "55512E4567", "124 Conch Street" );
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("111", "spongebob", "squarepant", "5551234567", null );
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("111", "spongebob", "squarepant", "5551234567", "" );
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("111", "spongebob", "squarepant", "5551234567", "124 Conch Street, Bikini Bottom, Pacific Ocean" );
		});
	}
	
	// To test the contact updates to validate information
	@Test
	void testContactUpdateMethods() {
		Contact contact = new Contact("25", "barry", "bonds", "4159722000", "24 Willie Mays Plaza" );
		contact.setFirstName("mark");
		assertTrue(contact.getFirstName().equals("mark"));
		contact.setLastName("mcgwire");
		assertTrue(contact.getLastName().equals("mcgwire"));
		contact.setNumber("3143459600");
		assertTrue(contact.getNumber().equals("3143459600"));
		contact.setAddress("700 Clark Avenue");
		assertTrue(contact.getAddress().equals("700 Clark Avenue"));
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName("");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName("Christopher");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setLastName(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setLastName("");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setLastName("Carrpenters");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setNumber(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setNumber("1");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setNumber("012345678910");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setNumber("31434S9600");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setAddress(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setAddress("700 Clark Avenue, St. Louis Missouri 63102");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName("");
		});
	}
}
