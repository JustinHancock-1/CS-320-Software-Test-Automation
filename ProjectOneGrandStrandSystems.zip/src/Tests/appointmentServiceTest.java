package Tests;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import Services.Appointment;
import Services.appointmentService;

class appointmentServiceTest {

	// creating a date
		Date createADate() {
			Calendar c = Calendar.getInstance();
			c.set(2023, 9, 31, 9, 15);
			Date date = c.getTime();
			return date;
		}
		// creating a date that is before todays date
		Date createBadDate() {
			Date date = new Date();
			date.setTime(1000000);
			return date;
		}
		
		// Testing add appointment constructor
		@Test
		void testConstructor() {
			appointmentService apptService = new appointmentService();
			assertTrue(apptService.GetAppointmentList().isEmpty());
			assertEquals(apptService.GetAppointmentCount(), 0);
			
			apptService.AddAppointment(createADate(), "Description");		
			apptService.PrintAppointmentList();
		}
		// testing adding if date is empty
		@Test
		void testAddAppointmentMethodNullDate() {
			appointmentService appointmentService = new appointmentService();
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				appointmentService.AddAppointment(null, "Description");
			});
		}
		// testing adding if description is empty
		@Test
		void testAddAppointmentMethodNullDescription() {
			appointmentService appointmentService = new appointmentService();
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				appointmentService.AddAppointment(createADate(), null);
			});
		}
		// testing adding if the date is bad
		@Test
		void testAddAppointmentMethodBadDate() {
			appointmentService appointmentService = new appointmentService();
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				appointmentService.AddAppointment(createBadDate(), "Description");
			});
		}
		// testing adding if description is bad
		@Test
		void testAddAppointmentMethodBadDescription() {
			appointmentService appointmentService = new appointmentService();
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				appointmentService.AddAppointment(createADate(), "ThisIsn'tLikeADoctorsAppointmentLet'sMakeThisAFunAppointmentLikeThePark");
			});
		}
		// testing adding if all parameters are met
		@Test
		void testAddAppointmentMethodWithValidParameters() {
			appointmentService appointmentService = new appointmentService();
			appointmentService.AddAppointment(createADate(), "AnAppointmentInTheParkForLunch");
			assertEquals(appointmentService.GetAppointmentCount(), 1);
			assertTrue(!appointmentService.GetAppointmentList().isEmpty());
			appointmentService.PrintAppointmentList();	
		}
		
		// Testing remove appointment empty list
		@Test
		void testRemoveMethodListEmpty() {
			appointmentService appointmentService = new appointmentService();
			// if list is empty
			appointmentService.RemoveAppointment("1234567");
		}
		// testing removing if ID is empty
		@Test
		void testRemoveMethodIDNull() {
			appointmentService appointmentService = new appointmentService();
			appointmentService.AddAppointment(createADate(), "to remove");
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				appointmentService.RemoveAppointment(null);
			});
		}
		// testing removing if ID is bad
		@Test 
		void testRemoveMethodIDTooLong() {
			appointmentService appointmentService = new appointmentService();
			appointmentService.AddAppointment(createADate(), "to remove");
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				appointmentService.RemoveAppointment("1234567800090123");
						
			});
		}
		// testing removing if appointment isn't in the list
		@Test
		void testRemoveMethodAppointmentNotInList() {
			appointmentService appointmentService = new appointmentService();
			appointmentService.AddAppointment(createADate(), "to remove");
			appointmentService.RemoveAppointment("1234567");
			// can't get this one to turn green not sure why
			assertTrue(!appointmentService.GetAppointmentList().isEmpty());
		}
		// testing removing if appointment is in the list
		@Test
		void testRemoveMethodAppointmentIsInList() {
			appointmentService appointmentService = new appointmentService();
			appointmentService.AddAppointment(createADate(), "to remove");
			Appointment appt = appointmentService.GetAppointmentList().elementAt(0);
			appointmentService.RemoveAppointment(appt.GetID());
			assertTrue(appointmentService.GetAppointmentList().isEmpty());
		}

}
