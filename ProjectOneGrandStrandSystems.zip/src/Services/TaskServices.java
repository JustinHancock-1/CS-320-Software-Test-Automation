package Services;

import java.util.ArrayList;

import Services.Task;

public class TaskServices {
	
	// creating a bucket to store the list of tasks
	public ArrayList<Task> taskList = new ArrayList<Task>();
	
	// displaying the list of contacts to the console to check for errors
	public void printTaskList() {
		for (int counter = 0; counter < taskList.size(); counter++) {
			System.out.println("\t Task ID: " + taskList.get(counter).getTaskID());
			System.out.println("\t Task Name: " + taskList.get(counter).getTaskName());
			System.out.println("\t Task Description: " + taskList.get(counter).getTaskDesc());
		}
	}
	
	// adding a new task to the constructor and the list
	public void addTask(String taskName, String taskDescription) {
		// creating the new task
		Task task = new Task(taskName, taskDescription);
		taskList.add(task);
	}
	
	// using taskID to return object and error checking for empty object
	public Task getTask(String taskID) {
		Task task = new Task(null, null);
		for (int counter = 0; counter < taskList.size(); counter++) {
			if (taskList.get(counter).getTaskID().contentEquals(taskID)) {
				task = taskList.get(counter);
			}
		}
		return task;
	}
	
	
	// deleting a task using the taskID to find the correct task to delete
	// prints to console if taskID was not found through the list
	public void deleteTask(String taskID) {
		for (int counter = 0; counter < taskList.size(); counter++) {
			if (taskList.get(counter).getTaskID().equals(taskID)) {
				taskList.remove(counter);
				break;
			}
			if (counter == taskList.size() - 1) {
				System.out.println("Task ID: " + taskID + " not found.");
			}
		}
	}
	
	// updating a taskName
	// prints to console if taskID was not found through the list
	public void updateTaskName(String updatedName, String taskID) {
		for (int counter = 0; counter < taskList.size(); counter++) {
			if (taskList.get(counter).getTaskID().equals(taskID)) {
				taskList.get(counter).setTaskName(updatedName);
				break;
			}
			if (counter == taskList.size() - 1) {
				System.out.println("Task ID: " + taskID + " not found.");
			}
		}
	}
	
	// updating a taskDescription
	public void updateTaskDescription(String updatedDescription, String taskID) {
		for (int counter = 0; counter < taskList.size(); counter++) {
			if (taskList.get(counter).getTaskID().equals(taskID)) {
				taskList.get(counter).setTaskDescription(updatedDescription);
				break;
			}
			if (counter == taskList.size() - 1) {
				System.out.println("Task ID: " + taskID + " not found.");
			}
		}
	}
}
