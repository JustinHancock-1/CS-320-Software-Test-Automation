package Services;

import java.util.Date;

public class Appointment {
	
	private String apptID;
	private Date apptDate;
	private String apptDescription;
	
	// creating an object that assigns appointment ID, date, and description with specific parameters
	public Appointment(String ID, Date date, String description) {
		if (ID == null || ID.length() >  10) {
			throw new IllegalArgumentException("Incorrect ID");
		}
		if (date == null || date.before(new Date())) {
			throw new IllegalArgumentException("Incorrect Appointment Date");
		}
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Incorrect Description");
		}
		
		apptID = ID;
		apptDate = date;
		apptDescription = description;
	}
	
	
	// method to get ID
	public String GetID() {
		return apptID;
	}
	// method to get Date
	public Date GetApptDate() {
		return apptDate;
	}
	// method to get description
	public String GetDescription() {
		return apptDescription;
	}
	
	// method to set the date
	public void SetApptDate(Date date) {
		if (date == null || date.before(new Date())) {
			throw new IllegalArgumentException("Invalid Appointmene Date");
		}
		apptDate = date;
	}
	// method to set the description
	public void SetApptDescription(String description) {
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		apptDescription = description;
	}
	
}
