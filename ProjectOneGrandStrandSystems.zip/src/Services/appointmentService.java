package Services;

import java.util.Date;
import java.util.Random;
import java.util.Vector;

public class appointmentService {

	private Vector<Appointment> appointmentList = new Vector<Appointment>();
	private int appointmentCount = 0;

	public Vector<Appointment> GetAppointmentList(){
		return appointmentList;
	}
	public int GetAppointmentCount() {
		return appointmentCount;
	}
	// printing appointments to the console
	public void PrintAppointmentList() {
		for (Appointment a : appointmentList) {
			System.out.println("Appointment ID: " + a.GetID() +
					"\nAppointment Date: " + a.GetApptDate().toString() +
					"\nAppointment Description: " + a.GetDescription());
		}
	}
	
	// adding appointments with validation
	public void AddAppointment(Date date, String description) {
		Date today = new Date();
		if (date == null || date.before(today)) {
			throw new IllegalArgumentException("Incorrect Appointment Date");
		}
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Incorrect Description");
			
		}
		String newID = GenerateUniqueID();
		Appointment newAppointment = new Appointment(newID, date, description);
		appointmentList.add(newAppointment);
		appointmentCount = GetAppointmentCount() + 1;
	}
	
	// deleting appointments with validation
	public void RemoveAppointment(String id) {
		if (appointmentList.isEmpty()) {
			System.out.println("There are no appointments.");
			
		}
		if (id == null || id.length() > 10) {
			throw new IllegalArgumentException("Incorrect ID for appointment.");
			
		}
		
		// looping through ID for appointments
		int index = -1;
		for (Appointment a : appointmentList) {
			if (a.GetID() == id) {
				index = appointmentList.indexOf(a);
			}
			
		}
		// validating if an ID wasn't found
		if (index == -1) {
			System.out.println("Appointment ID was not found.");
			return;
		}
		else {
			//removing the validated appointment
			appointmentList.remove(index);
			appointmentCount = GetAppointmentCount() - 1;
			System.out.println("Appointment removed");
		}
	}
	
	// generating an ID number for the created appointment
	public String GenerateUniqueID() {

		int count = 0;
		
		Random rand = new Random();
		int newID = rand.nextInt(1000000000);
		String uniqueID = Integer.toString(newID);
		
		// creating a temporary vector to hold ID
		Vector<String> idList = new Vector<String>();
		// filling the vector with current ID
		for (Appointment a : appointmentList) {
			idList.add(a.GetID());
		}
		
		// comparing created ID to list of current
		while (idList.contains(uniqueID) || uniqueID.length() > 10) {
			// creating a new ID if a match was found
			newID = rand.nextInt(1000000000);
			uniqueID = Integer.toString(newID);
			count++;
			if (count > 1000000000) {
				System.out.println("No more ID's");
				break;
			}
		}
		// deleting the temporary vector
		idList = null;
		// returning the created ID
		return uniqueID;
	}

}
