package Services;

public class Contact {
	
	private final String ID; // to make the ID attribute unchangeable
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;

	// creating the constructor which throws errors if values don't meet standards.
	public Contact(String id, String firstName, String lastName, String phoneNumber, String address) {
		
		if (id == null || id.length() > 10 || id.length() < 1) {
			throw new IllegalArgumentException("Invalid id.");
		}
		else if (firstName == null || firstName.length() > 10 || firstName.length() < 1) {
			throw new IllegalArgumentException("Invalid first name.");
		}
		else if (lastName == null || lastName.length() > 10 || lastName.length() < 1) {
			throw new IllegalArgumentException("Invalid last name.");
		}
		else if (phoneNumber == null || phoneNumber.length() != 10 || testPhone(phoneNumber)) { // see function below for number validation.
			throw new IllegalArgumentException("Invalid phone number."); 
		}
		else if (address == null || address.length() > 30 || address.length() < 1) {
			throw new IllegalArgumentException("Invalid address.");
		}
		else {
			this.ID = id;
			this.firstName = firstName;
			this.lastName = lastName;
			this.phoneNumber = phoneNumber;
			this.address = address;
		}
	}
	
	// creating a function that validates the phone number is all numerical values
	private Boolean testPhone(String number) {
		try {
			Long.parseLong(number);
			return false;
		}
		catch ( Exception e) {
			return true;
		}
	}
	
	// method returning ID.
	public String getid() {
		return ID;
	}
		
	// method returning first name.
	public String getFirstName() {
		return firstName;
	}
		
	// method updating first name.
	public void setFirstName(String newFirst) {
		if (newFirst == null || newFirst.length() > 10 || newFirst.length() < 1) {
			throw new IllegalArgumentException("Invalid first name.");
		}
		else {
			firstName = newFirst;
		}
	}
		
	// method returning last name.
	public String getLastName() {
		return lastName;
	}
		
	// method updating last name.
	public void setLastName(String newLast) {
		if (newLast == null || newLast.length() > 10 || newLast.length() < 1) {
			throw new IllegalArgumentException("Invalid last name.");
		}
		else {
			lastName = newLast;
		}
	}
		
	// method returning phone number.
	public String getNumber() {
		return phoneNumber;
	}
		
	// method updating phone number.
	public void setNumber(String newNumber) {
		if (newNumber == null || newNumber.length() != 10 || testPhone(newNumber)) {
			throw new IllegalArgumentException("Invalid phone number.");
		}
		else {
			phoneNumber = newNumber;
		}
	}
		
	// method returning contact address.
	public String getAddress() {
		return address;
	}
		
	// method updating contact address.
	public void setAddress(String newAddress) {
		if (newAddress == null || newAddress.length() > 30 || newAddress.length() < 1) {
			throw new IllegalArgumentException("Invalid address.");
		}
		else {
			address = newAddress;
		}
	}
}

