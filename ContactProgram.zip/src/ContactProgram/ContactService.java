package ContactProgram;

import ContactProgram.Contact;
import java.util.ArrayList;

public class ContactService {
	
	// creating a new list to hold contacts
	private ArrayList<Contact> ContactList;
	private ArrayList<String> IDs;
	
	// default constructor with empty lists
	public ContactService() {
		ContactList = new ArrayList<Contact>();
		IDs = new ArrayList<String>();
	}
	
	// method that adds and validates new contact and unique ID to the list
	public void addContact(String id, String firstName, String lastName, String phoneNumber, String address) {
		if (IDs.contains(id) || (id == null)) {
			throw new IllegalArgumentException("Not a unique ID.");
		}
		else {
		Contact newContact = new Contact(id, firstName, lastName, phoneNumber, address);
		IDs.add(id);
		ContactList.add(newContact);
		}
	}
	
	// method that deletes a contact and its ID from the list
	public void deleteContact(String id) {
		if (IDs.contains(id)) {
		ContactList.remove(IDs.indexOf(id));
		IDs.remove(id);
		}
		else {
			throw new IllegalArgumentException("No ID found.");
		}
	}
	
	// method that updates contact info referencing ID 
	public void updateContact(String id, String field, String value) {
		if (IDs.contains(id) && field != null) {
			switch (field) {
			    case "FirstName": ContactList.get(IDs.indexOf(id)).setFirstName(value);
			    break;
			    case "LastName": ContactList.get(IDs.indexOf(id)).setLastName(value);
			    break;
			    case "PhoneNumber": ContactList.get(IDs.indexOf(id)).setNumber(value);
			    break;
			    case "Address": ContactList.get(IDs.indexOf(id)).setAddress(value);
			    break;
			    default: throw new IllegalArgumentException("Information not recognized.");
			}
		}
		else {
			throw new IllegalArgumentException("No ID found to update.");
		}
	}
}
