package TaskServices;

import java.util.concurrent.atomic.AtomicLong;

public class Task {
	
	private final String taskID;
	private String taskName;
	private String taskDescription;
	private static AtomicLong IDCreator = new AtomicLong();
	
	// constructor to check all objects if empty or meets standards
	public Task(String taskName, String taskDescription) {
		
		// Task ID is automatically created when constructor is called
		// ID is set as the final variable so it cannot be changed
this.taskID = String.valueOf(IDCreator.getAndIncrement());
		
		if (taskName == null || taskName.isEmpty()) {
			this.taskName = "NULL";
		} else if (taskName.length() > 20) {
			this.taskName = taskName.substring(0, 20);
		} else {
			this.taskName = taskName;
		}
		
		if (taskDescription == null || taskDescription.isEmpty()) {
			this.taskDescription = "NULL";
		} else if (taskDescription.length() > 50) {
			this.taskDescription = taskDescription.substring(0, 50);
		} else {
			this.taskDescription = taskDescription;
		}
		
	}
	
	// method to get taskID
	public String getTaskID() {
		return taskID;
	}
	
	// method to get taskName
	public String getTaskName() {
		return taskName;
	}
	
	//method to get taskDescription
	public String getTaskDesc() {
		return taskDescription;
	}
	
	// method to set taskName
	public void setTaskName(String taskName) {
		if (taskName == null || taskName.isEmpty()) {
			this.taskName = "NULL";
		} else if (taskName.length() > 20) {
			this.taskName = taskName.substring(0, 20);
		} else {
			this.taskName = taskName;
		}
	}
	
	// method to set taskDescription
	public void setTaskDescription(String taskDescription) {
		if (taskDescription == null || taskDescription.isEmpty()) {
			this.taskDescription = "NULL";
		} else if (taskDescription.length() > 50) {
			this.taskDescription = taskDescription.substring(0, 50);
		} else {
			this.taskDescription = taskDescription;
		}
	}
}
