package Tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import TaskServices.Task;

class TaskTest {
	
	// testing that taskID has 10 characters or less
	@Test
	@DisplayName("Task ID can't have over 10 characters")
	void testTaskIDWithOverTenCharacters() {
		Task task = new Task("Name", "Description");
		if (task.getTaskID().length() > 10) {
			fail("Task ID has more than 10 characters.");
		}
	}
	
	// testing that taskName has 20 characters or less
	@Test
	@DisplayName("Task name can't have over 20 characters")
	void testTaskNameWithOverTwentyCharacters() {
		Task task = new Task("BatterHitsABallInTheRightFieldGap", "Description");
		if (task.getTaskName().length() > 20) {
			fail("Task Name has more than 20 characters.");
		}
	}
	
	// testing that taskDescription has 50 characters or less
	@Test
	@DisplayName("Task description can't have over 50 characters")
	void testTaskDescriptionWithOverFiftyCharacters() {
		Task task = new Task("Name", "HeTakesAWideTurnAtFirstAndHeadsToSecondBaseThrowComesInRunnerSlides...SAFE!");
		if (task.getTaskDesc().length() > 50) {
			fail("Task Description has more than 50 characters.");
		}
	}
	
	// testing that taskName is not empty
	@Test
	@DisplayName("Task name is not be empty")
	void testTaskNameNotNull() {
		Task task = new Task(null, "Description");
		assertNotNull(task.getTaskName(), "Task Name was empty.");
	}
	
	// testing that taskDescription is not empty
	@Test
	@DisplayName("Task description is not be empty")
	void testTaskDescNotNull() {
		Task task = new Task("Name", null);
		assertNotNull(task.getTaskDesc(), "Task description was empty.");
	}
}
