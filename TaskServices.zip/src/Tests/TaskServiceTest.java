package Tests;

import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import TaskServices.Task;
import TaskServices.TaskServices;

class TaskServiceTest {

	@Test
	@DisplayName("Test to update task name")
	void testUpdateTaskName() {
		TaskServices service = new TaskServices();
		service.addTask("Task Name", "Description");
		service.updateTaskName("Updated Task Name", "3");
		service.printTaskList();
		assertEquals("Updated Task Name", service.getTask("3").getTaskName(), "Task name wasn't updated.");
	}

	@Test
	@DisplayName("Test to update task description.")
	void testUpdateTaskDesc() {
		TaskServices service = new TaskServices();
		service.addTask("Task Name", "Description");
		service.updateTaskDescription("Updated Description", "1");
		service.printTaskList();
		assertEquals("Updated Description", service.getTask("1").getTaskDesc(), "Task description wasn't updated.");
	}

	@Test
	@DisplayName("Test to make sure that service deletes tasks.")
	void testDeleteContact() {
		TaskServices service = new TaskServices();
		service.addTask("Task Name", "Description");
		service.deleteTask("0");
		// making sure that the contactList is empty by creating a new empty contactList to compare
		ArrayList<Task> taskListEmpty = new ArrayList<Task>();
		service.printTaskList();
		assertEquals(service.taskList, taskListEmpty, "The task wasn't deleted.");
	}

	@Test
	@DisplayName("Test to make sure that service adds a task.")
	void testAddContact() {
		TaskServices service = new TaskServices();
		service.addTask("Task Name", "Description");
		service.printTaskList();
		assertNotNull(service.getTask("0"), "Task wasn't added correctly.");
	}

}
