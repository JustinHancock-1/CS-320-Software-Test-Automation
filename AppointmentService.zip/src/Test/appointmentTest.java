package Test;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import appointmentService.Appointment;

class appointmentTest {

	@Test
	void testAppointmentConstructors() {
		Calendar d = Calendar.getInstance();
		d.set(2023, 10, 5, 9, 15);
		Date date = d.getTime();
		
		
		//Date date = new Date(2023, 1, 10);
		System.out.println("The appointment date is " + date);
		
		
		
		// testing ID length
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("12345678910", date, "Appointment Description");
		});
		// testing if ID is empty
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment(null, date , "Appointment Description");
		});
		// testing if description is too long
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("1234567890", date , "ThisIsn'tLikeADoctorsAppointmentLet'sMakeThisAFunAppointmentLikeThePark");
		});
		// testing if description is empty
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("1234567890", date , null);
		});
		// testing if date is empty
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("1234567890", null , "Appointment Description");
		});
		// testing date before today
		date.setTime(0);
		System.out.println("The date is set to " + date);
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("1234567890", date , "Appointment Description");
		});
		// testing trues
		Date newDate = d.getTime();
		Appointment appt = new Appointment("1234567890", newDate, "Appointment Description");
		assertTrue(appt.GetID().equals("1234567890"));
		assertTrue(appt.GetApptDate().equals(newDate));
		assertTrue(appt.GetDescription().equals("Appointment Description"));
	}

}
